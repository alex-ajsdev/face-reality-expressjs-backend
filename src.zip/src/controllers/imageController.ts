import { Request, Response } from 'express';
import { getImages } from '../fsOperations';

const handleResponse = async (
  req: Request,
  res: Response,
  imageSets: string[]
) => {
  try {
    res.status(200).json(getImages(imageSets));
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'An unknown error occurred';
    res.status(500).json({ message });
  }
};

export const getStylegan = async (req: Request, res: Response) => {
  handleResponse(req, res, ['ffhq', 'stylegan']);
};

export const getStylegan2 = async (req: Request, res: Response) => {
  handleResponse(req, res, ['ffhq', 'stylegan2']);
};

export const getProgan = async (req: Request, res: Response) => {
  handleResponse(req, res, ['ffhq', 'progan']);
};
