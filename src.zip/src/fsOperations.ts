import path from 'path';
import fs from 'fs';

const IMAGE_DIRECTORY = path.join(__dirname, '..', 'img');
const TOTAL_IMAGES = 9;
const VALID_EXTENSIONS = ['.jpg', '.jpeg', '.png'];

function getValidImagesFromDirectory(directoryPath: string): string[] {
  return fs
    .readdirSync(directoryPath)
    .filter((file) => VALID_EXTENSIONS.includes(path.extname(file)));
}

function getRandomImageFromSet(
  set: string,
  excludedImages: Image[] = []
): Image | undefined {
  const directoryPath = path.join(IMAGE_DIRECTORY, set);
  const images = getValidImagesFromDirectory(directoryPath).filter(
    (img) =>
      !excludedImages.some(
        (selected) => selected.id === img && selected.set === set
      )
  );

  if (images.length === 0) return;

  const randomImage = images[Math.floor(Math.random() * images.length)];
  return {
    id: randomImage,
    set: set,
    url: `img/${set}/${randomImage}`
  };
}

export function getImages(imageSets: string[]): Image[] {
  const selectedImages: Image[] = [];

  // Ensure at least one image from each set
  for (const set of imageSets) {
    const image = getRandomImageFromSet(set);
    if (image) selectedImages.push(image);
  }

  // Fill in the rest of the images
  while (selectedImages.length < TOTAL_IMAGES) {
    const randomSet = imageSets[Math.floor(Math.random() * imageSets.length)];
    const image = getRandomImageFromSet(randomSet, selectedImages);
    if (image) selectedImages.push(image);
  }

  return selectedImages;
}

interface Image {
  id: string;
  set: string;
  url: string;
}
