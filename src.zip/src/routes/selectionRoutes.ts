import express from 'express';
import * as selectionController from '../controllers/selectionController';

const router = express.Router();

router.get('/', selectionController.getAllSelections);
router.post('/', selectionController.createSelection);

export default router;
