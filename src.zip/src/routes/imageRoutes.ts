import express from 'express';
import * as imageController from '../controllers/imageController';

const router = express.Router();

router.get('/stylegan/', imageController.getStylegan);
router.get('/stylegan2/', imageController.getStylegan2);
router.get('/progan/', imageController.getProgan);

export default router;
