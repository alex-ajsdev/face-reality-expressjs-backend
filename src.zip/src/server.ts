import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import imageRoutes from './routes/imageRoutes';
import selectionRoutes from './routes/selectionRoutes';

dotenv.config();

const app = express();
const MONGO_URI = process.env.MONGO_URI;
const PORT = Number(process.env.PORT);

// const selectionSchema = new mongoose.Schema({
//   totalFake: Number,
//   totalFakeFound: Number,
//   totalRealFound: Number,
//   algorithm: String
// });

// const Selection = mongoose.model('Selection', selectionSchema);

// Connect to MongoDB Atlas
if (MONGO_URI != null) {
  mongoose
    .connect(MONGO_URI)
    .then(() => console.log('Connected to MongoDB Atlas'))
    .catch((err) => console.error('Could not connect to MongoDB Atlas:', err));
} else {
  console.log(
    'Failed to connect to MongoDB. MONGO_URI was not assigned in enviornment variables.'
  );
}

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Routes
app.use(`/img`, express.static('img'));
app.use('/images', imageRoutes);
app.use('/selections', selectionRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
